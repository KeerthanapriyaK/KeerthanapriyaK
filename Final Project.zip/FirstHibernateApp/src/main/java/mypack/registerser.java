package mypack;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.cfg.Configuration;


public class registerser extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void service(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		// hibernate code to add a record
		 
		RequestDispatcher rs;
		
		Configuration cfg = new Configuration();
		Session S = cfg.configure("connect.cfg.xml").buildSessionFactory().openSession();
		
		S.getTransaction().begin();
		
		
		String mail = request.getParameter("email_id");
		
		String pswd = request.getParameter("pwd");
		
		users p = new users();
		
		p.setEmail_id(mail);
		
		p.setPwd(pswd);
		
		S.save(p);
		
		S.getTransaction().commit();
		
	
		
		
		
		S.close();
		
		rs = request.getServletContext().getRequestDispatcher("/login.jsp");	
		rs.forward(request, response);
				
	}

}
