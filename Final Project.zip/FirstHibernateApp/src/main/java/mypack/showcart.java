package mypack;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;

import mypack.users;
import mypack.cart;
import mypack.product;

/**
 * Servlet implementation class addtocart
 */
public class showcart extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		 RequestDispatcher rs;
		
		 String	mail = request.getParameter("mai");
		
		
		

		
		
		Configuration cfg = new Configuration();	  
		Session S = cfg.configure("connect.cfg.xml").buildSessionFactory().openSession();
		
		S.getTransaction().begin();
		
		
			
			
		
		
       
		
		
		
		
		  cart e= null;
		 
		  Query qwr =S.createQuery(" from cart e where e.email_id=:VAL "); // named parameter
		  
		  qwr.setParameter("VAL", mail);
		  
		  List L9 = qwr.list();
			
			
			
		request.setAttribute("cartrc",L9);
		
		
		rs = request.getServletContext().getRequestDispatcher("/cart.jsp");	
		rs.forward(request, response);
		
		S.close();
		
		
		
		
		
		
		

		
	}

}
