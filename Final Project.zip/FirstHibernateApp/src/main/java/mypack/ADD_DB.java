package mypack;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.cfg.Configuration;


public class ADD_DB extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void service(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		// hibernate code to add a record
		 
		RequestDispatcher rs;
		
		Configuration cfg = new Configuration();
		Session S = cfg.configure("connect.cfg.xml").buildSessionFactory().openSession();
		
		S.getTransaction().begin();
		
		
		String pnm = request.getParameter("pnm");
		int qty = Integer.parseInt(request.getParameter("qty"));
		int price = Integer.parseInt(request.getParameter("price"));
		String mft = request.getParameter("mft");
		String pic = request.getParameter("pic");
		
		product p = new product();
		p.setPnm(pnm);
		p.setPrice(price);
		p.setQty(qty);
		p.setManufactuer(mft);
		p.setPic(pic);
		
		S.save(p);
		
		S.getTransaction().commit();
		
	
		
		Query q =S.createQuery("from product p"); 
		 
		List L1 = q.list();
									
		request.setAttribute("prdt",L1);
		
		S.close();
		
		rs = request.getServletContext().getRequestDispatcher("/adminpanel.jsp");	
		rs.forward(request, response);
				
	}

}
