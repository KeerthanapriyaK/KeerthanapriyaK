package mypack;

import javax.persistence.*;

@Entity
@Table(name="product",uniqueConstraints = {
        @UniqueConstraint(columnNames = "prid")
        })



@NamedQueries
(
  {
    @NamedQuery(name="getbyid", query="from product p where p.prid=:id"),
    @NamedQuery(name="getbyqty", query="from product p where p.qty >=:ty")
  }
)



public class product 
{
	@Id	
	@GeneratedValue(strategy = GenerationType.IDENTITY) int prid;

	@Column(name="pnm") 
	public String pnm;
	
	@Column(name="qty")
	public int qty;
	
	@Column(name="price")
	public int price;	
	
	@Column(name="manufactuer")
	public String manufactuer;
	
	/*@Column(name="img")
	public String img;
	
	@Column(name="decc")
	public String decc;*/
	

	@Column(name="pic")
	public String pic;
			
	public String toString()
	{
		return "\nProduct Id: "+getPrid()+"\nProduct Name : "+getPnm()+"\nQuantity : "+getQty()+"\nPrice: "+getPrice()+"\nManufacturer: "+"\nPicture: "+getPic();		
	}
	
	
	public int getPrid() {
		return prid;
	}
	public void setPrid(int prid) {
		this.prid = prid;
	}
	public String getPnm() {
		return pnm;		
	}
	public void setPnm(String pnm) {
		this.pnm = pnm;
	}
	public int getQty() {
		return qty;
	}
	public void setQty(int qty) {
		this.qty = qty;
	}
	
	
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	
/*	
	public String getImage() {
		return img;
	}
	public void setImage(String img) {
		this.img = img;
	}*/
	
	public String getManufactuer() {
		return manufactuer;
	}
	public void setManufactuer(String manufactuer) {
		this.manufactuer = manufactuer;
	}
	
	/*public String getDescription() {
		return decc;
	}
	public void setDescription(String decc) {
		this.decc = decc;
	}*/
	
	public String getPic() {
		return pic;
	}
	public void setPic(String pic) {
		this.pic = pic;
	}
}