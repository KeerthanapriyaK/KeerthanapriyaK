package mypack;

import javax.persistence.*;

@Entity
@Table(name="users")
public class users 
{
	@Id	
	@GeneratedValue(strategy = GenerationType.IDENTITY) String email_id;

	@Column(name="pwd")
	private String pwd;
	
	@Column(name="email_id")
	public String getEmail_id() {
		return email_id;
	}

	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	
	public String toString()
	{
		return getEmail_id()+"exists";
	}
			
	
	
}
