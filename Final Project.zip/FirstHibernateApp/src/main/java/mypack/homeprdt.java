package mypack;



import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.cfg.Configuration;


import mypack.product;


public class homeprdt extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		 RequestDispatcher rs;
		
		Configuration cfg = new Configuration();	  
		Session S = cfg.configure("connect.cfg.xml").buildSessionFactory().openSession();
		
		
		
		 
		Query q =S.createQuery("from product p"); 
	 				 
		List L1 = q.list();
									
		request.setAttribute("prdt",L1);
		
	rs = request.getServletContext().getRequestDispatcher("/home.jsp");
	
	
	rs.forward(request, response);
  	
	S.close();
	//F.close();
	
}

}
